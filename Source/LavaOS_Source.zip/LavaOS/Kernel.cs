﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using Sys = Cosmos.System;
using LavaOS.Programs;
using LavaOS.Commands;

namespace LavaOS
{
    public class Kernel : Sys.Kernel
    {
        Sys.FileSystem.CosmosVFS fs = new Sys.FileSystem.CosmosVFS();
        public static string cmd = Console.ReadLine();

        protected override void BeforeRun()
        {
            Sys.FileSystem.VFS.VFSManager.RegisterVFS(fs);
            Console.Clear();
            Console.WriteLine("LavaOS booted successfully. Version 1.0.0 Prototype.");
            Console.WriteLine("Type Help for a list of commands");
            Console.WriteLine("Type run app Manual to see what the commands do");
            Console.WriteLine("Type run app Programs to see what programs there are");
            Console.WriteLine("If you use the run command, apps and programs will be case sensitive");
        }

        protected override void Run()
        {
            Console.Write("@: ");


            //Help
            if (cmd == "Help") { Help.Launch(); }
            
            if (cmd == "help") { Help.Launch(); }
            

            //ShutDown
            if (cmd == "shutdown") { ShutDown.Launch(); }
            
            if (cmd == "Shutdown") { ShutDown.Launch(); }

            //Echo
            if (cmd.StartsWith("echo ")) { Console.WriteLine(cmd.Remove(0, 5)); }
            
            if (cmd.StartsWith("Echo ")) { Console.WriteLine(cmd.Remove(0, 5)); }

            //Reboot
            if (cmd == "reboot") { Reboot.Launch(); }

            if (cmd == "Reboot") { Reboot.Launch(); }

            //Clear
            if (cmd == "clear") { Clear.Launch(); }

            if (cmd == "Clear") { Clear.Launch(); }

            //os
            if (cmd == "os") { OS.Launch(); }

            if (cmd == "Os") { OS.Launch(); }

            //add
            if (cmd == "add") { Add.Launch(); }

            if (cmd == "Add") { Add.Launch(); }

            //subtract
            if (cmd == "subtract") { Subtract.Launch(); }


            if (cmd == "Subtract") { Subtract.Launch(); }

            //multiply
            if (cmd == "multiply") { Multiply.Launch(); }

            if (cmd == "Multiply") { Multiply.Launch(); }

            //divide
            if (cmd == "divide") { Divide.Launch(); }


            if (cmd == "Divide") { Divide.Launch(); }

            //free disk space
            if (cmd == "freediskspace") {
                var available_space = fs.GetAvailableFreeSpace(@"0:\");
                Console.WriteLine("Available Free Space: " + available_space);
            }

            //file system type
            if (cmd == "filesystemtype")
            {
                var fs_type = fs.GetFileSystemType(@"0:\");
                Console.WriteLine("File System Type: " + fs_type);
            }

            //directory
            if (cmd == "dir")
            {
                var directory_list = Directory.GetFiles(@"0:\");

                foreach (var file in directory_list)
                {
                    Console.WriteLine(file);
                }
            }

            //run
            if (cmd.StartsWith("run app ")) 
            {
                string app = cmd.Remove(0, 8);
                if (app == "Manual")
                {
                    Console.Clear();
                    Manual.Launch();
                }

                if (app == "Time")
                {
                    Console.Clear();
                    Time.Launch();
                }

                if (app == "Programs")
                {
                    Console.Clear();
                    ProgramsList.Launch();
                }
            }
            
            if (cmd.StartsWith("Run App "))
            {

                string app = cmd.Remove(0, 8);
                if (app == "Manual")
                {
                    Console.Clear();
                    Manual.Launch();
                }

                if (app == "Time")
                {
                    Console.Clear();
                    Time.Launch();
                }

                if (app == "Programs")
                {
                    Console.Clear();
                    ProgramsList.Launch();
                }
            }

        }
    }
}

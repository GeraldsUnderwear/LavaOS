﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using static Cosmos.HAL.BlockDevice.ATA_PIO;
using Sys = Cosmos.System;

namespace LavaOS.Commands
{
    internal class Reboot
    {
        public string CommandName = "CommandTemp";

        public static void Launch()
        {

            MainLoop();

        }
        private static void MainLoop()
        {
            Console.WriteLine("Rebooting System... \n...");
            Sys.Power.Reboot();

            Close();

        }

        private static void Close()
        {



        }
    }
}


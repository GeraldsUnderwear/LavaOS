﻿using LavaOS.Programs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using static Cosmos.HAL.BlockDevice.ATA_PIO;
using Sys = Cosmos.System;

namespace LavaOS.Commands
{
    internal class CommandTemp
    {
        public string CommandName = "CommandTemp";

        public static void Launch()
        {

            MainLoop();

        }

        private static void MainLoop()
        {

            Console.WriteLine("Temp");

            Close();

        }

        private static void Close()
        {



        }
    }
}

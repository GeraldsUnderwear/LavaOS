﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using Sys = Cosmos.System;

namespace LavaOS.Commands
{
    internal class Divide
    {
        public string CommandName = "CommandTemp";

        public static void Launch()
        {

            MainLoop();

        }

        private static void MainLoop()
        {
            int num1 = 0; int num2 = 0;

            Console.WriteLine("Type the first number:");
            num1 = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Type the second number:");
            num2 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Your result: " + (num1 / num2));

            Close();
        }



        private static void Close()
        {



        }
    }
}

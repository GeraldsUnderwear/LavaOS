﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using Sys = Cosmos.System;

namespace LavaOS.Commands
{
    internal class Help
    {
        public string CommandName = "CommandTemp";

        public static void Launch()
        {

            MainLoop();

        }

        private static void MainLoop()
        {

            Console.WriteLine("help, echo, shutdown, reboot, os, clear, add, subtract, multiply, divide,");
            Console.WriteLine("freediskspace, filesystemtype, dir, run");

            Close();

        }

        private static void Close()
        {



        }
    }
}

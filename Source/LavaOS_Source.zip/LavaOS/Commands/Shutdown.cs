﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using Sys = Cosmos.System;

namespace LavaOS.Commands
{
    internal class ShutDown
    {
        public string CommandName = "CommandTemp";

        public static void Launch()
        {

            MainLoop();

        }

        private static void MainLoop()
        {

            Console.WriteLine("Closing System... \n...");
            Sys.Power.Shutdown();

            Close();

        }

        private static void Close()
        {



        }
    }
}

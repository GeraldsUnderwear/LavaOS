﻿using IL2CPU.API;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Emit;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using Sys = Cosmos.System;

namespace LavaOS.Programs
{
    internal class ProgramsList
    {
        public string AppName = "Programs";

        public static string AppDescription = "Check Programs";
        public static bool IsStable = false; //Change this to false when in Alpha or Beta 

        public static void Launch()
        {

            MainLoop();

        }

        private static void MainLoop()
        {

            Console.WriteLine("Programs List");
            Console.WriteLine("Press any key to continue");
            Console.ReadKey();
            Console.WriteLine($"Manual --- {Manual.AppDescription}");
            Console.WriteLine($"Time --- {Time.AppDescription}");
            Console.WriteLine($"Programs --- {ProgramsList.AppDescription}");



        }

        private static void Close()
        {

            Environment.Exit(0);

        }
    }
}

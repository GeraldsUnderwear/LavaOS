﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using Sys = Cosmos.System;

namespace LavaOS.Programs
{
    internal class AppTemp
    {
        public string AppName = "AppTemp";

        public static string AppDescription = "Temlate for apps";
        public static bool IsStable = false; //Change this to false when in Alpha or Beta 

        public static void Launch()
        {

            MainLoop();

        }

        private static void MainLoop()
        {

            Console.WriteLine("AppTemp");
            Console.WriteLine("Press any key to continue");
            Console.ReadKey();

            Close();

        }

        private static void Close()
        {

            Environment.Exit(0);

        }
    }
}
